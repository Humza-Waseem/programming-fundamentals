#include <iostream>
using namespace std;
main()
{
    string word;
    cout << "enter the string :";
    cin >> word;
    int length = 0;

    for (int i = 0; word[i] != '\0'; i++)
    {
        length++;
    }
    if (length % 2 == 0)
    {
        cout << "True" << endl;

        cout << "word apple has  " << length << "  letter";
    }
    else
    {
        cout << "false";
    }
}