#include <iostream>
using namespace std;
main()
{
    int n;
    cout << "Enter number of times even-odd transformation need to be done:";
    cin >> n;
    int arr[3];
    int i;
    for (i = 0; i < 3; i++)
    {
        cout << "enter the number :";
        cin >> arr[i];
    }
    for (i = 0; i < 3; i++)
    {
        if (arr[i] % 2 == 0)
        {
            cout << arr[i] - (2 * n);
        }
        if (arr[i] % 2 != 0)
        {
            cout << arr[i] + (2 * n);
        }
    }
}