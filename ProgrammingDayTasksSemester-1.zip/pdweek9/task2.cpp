#include <iostream>
using namespace std;
main()
{
    int price = 500;
    float bill;
    string name;
    float disc;

    string movies[5] = {"Gladiator", "StarWars", "Terminator", "TakingLives", "TombRider"};
    cout << "enter the movie name you want to find:";
    cin >> name;
    for (int i = 1; i < 5; i = i + 2)
    {

        if (movies[i] == name)
        {
            disc = price * 5 / 100;
            bill = price - disc;
            cout << "the price of the movie will be:" << bill;
            break;
        }
        else
        {
            continue;
        }
    }
    for (int i = 0; i < 5; i = i + 2)
    {
        if (movies[i] == name)
        {

            disc = price * 10 / 100;
            bill = price - disc;
            cout << "total price  :" << bill;
            break;
        }

        else

        {
            continue;
        }
    }
}