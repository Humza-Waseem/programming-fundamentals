#include <iostream>
using namespace std;
main()
{
    string arr[4];
    for (int i = 0; i < 4; i++)
    {
        cout << "enter the numbers :" << endl;
        cin >> arr[i];
    }

    if (arr[0] == arr[1] && arr[0] == arr[2] && arr[0] == arr[3])
    {
        cout << "same.";
    }
    else
    {
        cout << "not same.";
    }
}