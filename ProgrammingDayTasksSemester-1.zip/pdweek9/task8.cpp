#include <iostream>
using namespace std;
main()
{
    int n = 3;
    int x = 0;
    int time;

    cout << "enter the number of colours";
    cin >> n;

    string col[n];
    for (int i = 0; i < n; i++)
    {
        cout << "Enter the color:";
        cin >> col[i];
    }
    for (int i = 0; i < n; i++)
    {
        if (col[i] == col[++i])
        {
            x = x + 1;
        }
    }
    time = (2 * n) + (n - x - 1);
    cout << "time to color all boxes:" << time;
}