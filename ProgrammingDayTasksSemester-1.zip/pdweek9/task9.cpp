#include <iostream>
using namespace std;
main()
{
    string dance[9];
    string pin[4];
    for (int i = 0; i < 4; i++)
    {
        cout << "ENTER THE PIN:";
        cin >> pin[i];
    }
}