#include <iostream>
using namespace std;
main()
{
    int size;
    int arr[size];
    bool boom = false;
    cout << "enter the size of array:";
    cin >> size;

    for (int i = 0; i < size; i++)
    {
        cout << "enter the number:";
        cin >> arr[i];
    }
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == 7)
        {
            boom = true;
        }
    }
    if (boom == true)
    {
        cout << "boom";
    }
    else
        cout << "false";
}