#include <iostream>
using namespace std;
main()
{
    int sizeF = 4;
    int sizeP = 4;
    string fruitName[sizeF] = {"peach", "apple", "guava", "watermelon"};
    string find;
    int bill;
    int quantity;

    int price[sizeP] = {60, 70, 40, 30};
    cout << "enter the name of the fruit you want to find:";
    cin >> find;
    cout << "enter the quantity in kgs:";
    cin >> quantity;
    for (int i = 0; i < sizeF; i++)
    {
        if (fruitName[i] == find)
        {
            cout << fruitName[i] << "/t" << price[i];
            bill = quantity * price[i];
            cout << "bill = " << bill;
        }
        else
        {
            continue;
        }
    }
}