#include <iostream>
using namespace std;
main()
{
    int count = 0;
    int length1, length2;
    string word, word2;
    cout << "enter the string :";
    cin >> word;
    cout << "ENTER another string:";
    cin >> word2;
    length1 = word.length();
    length2 = word2.length();

    for (int x = 0; x < length1; x++)
    {
        for (int i = 0; i < length2; i++)
        {
            if (word[x] == word2[i])
            {
                count++;
                word2[i] = ' ';
                break;
            }
        }
    }
    cout << "no of common characters is:" << count;
}