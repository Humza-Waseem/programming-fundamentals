#include <iostream>
using namespace std;
main()
{
    int days;
    cout << "enter the days for examination:";
    cin >> days;
    int b;
    
    for (int i = 1; i <= days; i++)
    {
     cin>>b;
       
    }
    