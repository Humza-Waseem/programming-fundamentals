#include <iostream>
using namespace std;
main()
{
    int num;
    cout << "enter  number:";
    cin >> num;
    for (int i = 1; i <= num; i++)
    {
        if (i % 4 == 0)
            cout << i * 10 << endl;
        else
            cout << i << endl;
    }
}