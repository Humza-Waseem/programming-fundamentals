#include <iostream>
using namespace std;
main()
{
    int a;
    cout << "enter the triangle:";
    cin >> a;
    int count = 0;

    for (int i = 1; i <= a; i++)
    {
        count = count + i;
    }
    cout << count;
}