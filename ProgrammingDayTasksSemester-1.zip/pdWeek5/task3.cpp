#include <iostream>
using namespace std;

 main()
{
int itemPrice;
float taxamount;
char typeCode;
float taxRate;
cout<<"enter the price of vehicle:";
cin>>itemPrice;
cout<<"enter vehicle type code:";
cin>>typeCode;
 
float finalPrice;

     if(typeCode=='M')
     {
      taxRate= (itemPrice/100)*6 ;
      taxamount=itemPrice * (taxRate/100);
       
      finalPrice=itemPrice + taxamount;
      cout<<"final price for motorcycle is:"<<finalPrice;
  
      }
   
     if(typeCode=='E')
    {
      taxRate=(itemPrice/100)*8;
     taxamount= (itemPrice)*(taxRate/100);
     

    
      finalPrice=itemPrice + taxamount;
      cout<<"final price for electric is:"<<finalPrice;
      }
   


      if(typeCode=='S')
    {
      taxRate=(itemPrice/100)*10;
     taxamount= (itemPrice)*(taxRate/100);
     

    
      finalPrice=itemPrice + taxamount;
      cout<<"final price for sedan is:"<<finalPrice;
     }
 
       if(typeCode=='V')
    {
      taxRate=(itemPrice/100)*12;
     taxamount= (itemPrice)*(taxRate/100);
     

    
      finalPrice=itemPrice + taxamount;
      cout<<"final price for Van is:"<<finalPrice;
     }

       if(typeCode=='T')
    {
      taxRate=(itemPrice/100)*15;
     taxamount= (itemPrice)*(taxRate/100);
     

    
      finalPrice=itemPrice + taxamount;
      cout<<"final price for truck is:"<<finalPrice;
     }

   

  
  


}


