#include <iostream>
using namespace std;
void functionf(int height, int width,int length,string choice);

 main()
{
int height,width,length,volume;
string choice;

cout<<"enter height:";
cin>>height;
cout<<"enter width :";
cin>>width;
cout<<"enter length:";
cin>>length;

cout<<"enter unit in which you want to measure::";
cin>>choice;
functionf(height,width,length,choice);
}
void functionf(int height, int width,int length,string choice)
{
int volume;



 if (choice=="cubicCM")
 {
  volume=((height * 100)*( width*100)* (length*100))/3;

  cout<<"volume in cubicmeter is ="<<volume;
 }
  


  if (choice=="cubicK")
 {
  volume=((height*1000)*(width*1000)*(length*1000))/3;
  cout<<"volume in cm is ="<<volume;
 }



 if (choice=="cubicMM")
 {
  volume=(height/1000)*(width/1000)*(length/1000)/3;
  
  cout<<"volume in cubicmm is ="<<volume;
 }

  
}


