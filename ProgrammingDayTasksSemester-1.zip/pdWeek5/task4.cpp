#include<iostream>
using namespace std;
main()
{
 int hours;
 int days;
 int workers;
 int totaldays;
  
cout<<"hours needed are:";
cin>>hours;
 
cout<<"days that a firm has:";
cin>>days;
 
cout<<"number of workers needed:";
cin>>workers;

 int extratime=2hours;
 da
 hours = days * 8 * hours *;
 
cout<<"hours in "<<days<<"days"<<"are:"<<hours;

}
 
 

