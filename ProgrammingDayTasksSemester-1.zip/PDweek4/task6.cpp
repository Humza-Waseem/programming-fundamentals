#include<iostream>
using namespace std;
void letterA();
void letterW();
void letterI();
void letterS(); 
main()
{
    
letterA();
letterW();
letterA();
letterI();
letterS();

}
  void letterA()
  {
   cout<<"   #   "<<endl;
   cout<<"  ###  "<<endl;
   cout<<"  # #  "<<endl;
   cout<<" ##### "<<endl;
   cout<<" #   # "<<endl;
   cout<<" #   # "<<endl<<endl;
   }
  
  void letterW()
  {
   cout<<"#      #   "<<endl;
   cout<<"#   #  #   "<<endl;
   cout<<"#  ##  #    "<<endl;
   cout<<" #    #     "<<endl<<endl;
  }
  
  void letterS()
  { 
   cout<<" ######     "<<endl;
   cout<<" ##         "<<endl;
   cout<<" ######     "<<endl;
   cout<<"     ##     "<<endl;
   cout<<" ######     "<<endl<<endl;
   }
 
  void letterI()
  {
   cout<<" ######   "<<endl;
   cout<<"   ##     "<<endl;
   cout<<"   ##     "<<endl;
   cout<<"   ##     "<<endl;
   cout<<" ######   "<<endl<<endl;
   }
 

