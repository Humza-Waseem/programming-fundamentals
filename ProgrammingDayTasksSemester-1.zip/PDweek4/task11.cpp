#include<iostream>
using namespace std;
main()
{
int speed;
cout<<"enter the speeed";
cin>>speed;
  
  if(speed<=100)
  {
    cout<<"Perfect! You�re going good.";
  }
  if(speed>100)
  {
    cout<<"Halt..YOU WILL BE CHALLENGED!!!  ";
  }
}