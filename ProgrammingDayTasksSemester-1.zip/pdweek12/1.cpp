#include <iostream>
#include <fstream>
using namespace std;
void enterdata(string name, string age);
void storedata();

int i = 0;
main()
{
    string name, age;

    enterdata();
    storedata(name, age);
}
void enterdata()
{

    cout << "Enter the name:";
    cin >> name;
    cout << "Enter the age:";
    cin >> age;
}
void storedata()
{

    while (!EOF)
    {
        fstream file;
        file.open("example.txt", ios::out);
        file << name << " " << age;
        i++;
        file.close();
    }
}
