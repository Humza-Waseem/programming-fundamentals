#include<iostream>
using namespace std;
main()
{
cout<<"   -----------------------                                   "<<endl;
cout<<"     0    ^___^                                  "<<endl;
cout<<"      0   (0 0)\_____________                                  "<<endl;
cout<<"          (___)\            )\/\                                 "<<endl;
cout<<"                                      "<<endl;
cout<<"                ||------W |                               "<<endl;
cout<<"                ||       ||                                "<<endl;
cout<<"                                                    "<<endl;
cout<<"                                                      "<<endl;
cout<<"                                                         "<<endl; 
cout<<"                                                          "<<endl;
cout<<"                                                       "<<endl;
cout<<"                            "<<endl;
}                                             
