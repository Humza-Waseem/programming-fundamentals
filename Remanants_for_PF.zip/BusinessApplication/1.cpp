#include <iostream>
#include <windows.h>
using namespace std;

// functions declaration.
void logo();
void mainmenu();
void adminmenu();
void costumermenu();
bool signin();
void signup();
void generateColors();

// Global Variables
int option1, option2;

string name;
int pass;
string role;

string names[20];
int passw[20];
string roles[20];

int usercount = 0;

bool isfound = false;

// add car variables
int indx;
string car[6] = {"corolla", "gtr", "civic", "city", "cultus"};
string company[6] = {"toyota", "honda", "honda", "honda", "suzuki"};
float price[6] = {10000, 20000, 12000, 8000, 4000};
string cars, companys, prices;

// check availability variables
string avcar;
bool isavailable = false;

// check documents
int age;
char lisence;
// modify car variables
string modcar;

// rent car variables
string rentcar;
int days;
int pricerent;
// view price variables
string viewcar;
// compare car variables
string compcar1, compcar2;

main()
{

    logo();
    mainmenu();
}
void logo()

{
    generateColors();
    cout << "  ###     #####  #####       #####    ######    ##     ###   ########" << endl;
    cout << " #   #    #   #  #  #        #  #     #         ##     #       ###" << endl;
    cout << " #        #####  # #         # #      ######    #  #   #        #" << endl;
    cout << " #   #    #   #  #  #        #  #     #         #    # #        #" << endl;
    cout << "  ###     #   #  #   #       #   #    ######  ###     ##        #" << endl;
}
void mainmenu()
{
    int option;
    cout << "1. Sign In " << endl;
    cout << "2. Sign UP" << endl;
    cout << "3. Exit" << endl;
    cout << "Select any option." << endl;
    cin >> option1;
    if (option1 == 2)
    {
        signup();
    }
    if (option1 == 1)
    {
        signin();
    }
    if (option1 != 1 && option1 != 2 && option1 != 3)
    {
        cout << "YOU HAVE ENTERED WRONG OPTION!!";
    }
}
void signup()
{

    system("Cls");

    cout << "**********Sign Up************" << endl;
    cout << endl;
    cout << "Enter Username: ";
    cin >> names[usercount];
    cout << "Enter Password: ";
    cin >> passw[usercount];
    cout << "Enter Role: ";
    cin >> roles[usercount];

    if (names[usercount] == name && passw[usercount] == pass && roles[usercount] == role)
    {
        cout << "ID ALREADY EXISTS GO AND SIGN IN!!";
    }
    system("Cls");
    logo();
    mainmenu();
}
bool signin()
{

    // system("Cls");

    cout << "**********Sign IN**********" << endl;
    cout << endl;
    cout << "Enter Username: ";
    cin >> name;
    cout << "Enter Password: ";
    cin >> pass;
    cout << "Enter Role: ";
    cin >> role;
    for (int i = 0; i <= usercount; i++)
    {
        if (name == names[usercount] && pass == passw[usercount] && role == roles[usercount])
        {
            if (roles[usercount] == "admin")
            {
                adminmenu();
                break;
            }

            if (roles[usercount] == "costumer")
            {
                costumermenu();
                mainmenu();
                break;
            }
        }
        if (name != names[usercount] && pass != passw[usercount] && role != roles[usercount])

        {
            cout << "INVALID ID AND PASSWORD";
            break;
        }
    }
    return 0;
}

void adminmenu()
{
    cout << "********************ADMIN MENU********************" << endl;
    cout << "1.Add cars" << endl;
    cout << "2.Check Requests" << endl;
    cout << "3.View Custumer" << endl;
    cout << "4.Check availability " << endl;
    cout << "5.Remove Car" << endl;
    cout << "6.Check Documents" << endl;
    cout << "Select any option:";
    cin >> option2;
    system("Cls");
    if (option2 == 1)
    {

        cout << "********************ADD CARS********************" << endl;
        cout << endl;

        cout << "Enter Name of car: ";
        cin >> car[6];
        cout << "Enter Company: ";
        cin >> company[6];
        cout << "Enter Price: ";
        cin >> prices;
        int i;
        for (i = 0; i < 5; i++)
        {
            if (car[6] == car[i])
            {
                cout << "CAR ALREADY ENTERED";
            }
        }
    }
    if (option2 == 2)
    {
        cout << "********************Check Requests*********************" << endl;
        cout << endl;
        cout << "REQUESTS " << endl;
        cout << endl;
        cout << "--         --           --";
    }
    if (option2 == 3)
    {
        cout << "*******************View Costumer********************" << endl;
        cout << endl;
    }
    if (option2 == 4)
    {
        cout << "********************Check availability*******************" << endl;
        cout << endl;
        cout << "ENTER THE CAR: ";
        cin >> avcar;
        for (int i = 0; i < 6; i++)
        {
            if (avcar == car[i])
            {
                cout << "CAR IS AVAILABLE!" << endl;
                isavailable = true;
                break;
            }
        }
        if (isavailable = false)
        {
            cout << "CAR IS NOT AVAILABLE!";
        }
    }
    if (option2 == 5)
    {
        cout << "*******************MODIFY CAR********************" << endl;
        cout << endl;
        cout << "WHICH CAR YOU WANT TO SEND FOR MODIFICATION?? ";
        cin >> modcar;
        cout << modcar << " will be sent for modification " << endl;
    }
    if (option2 == 6)
    {
        cout << "*******************Check Documents********************" << endl;
        cout << endl;
        cout << "Enter the AGE of costumer: ";
        cin >> age;

        cout << "ENTER the AVAILABILTY OF LISENCE (y/n): ";
        cin >> lisence;
        if (age >= 18 && lisence == 'y')
        {
            cout << "COSTUMER IS CLEAR FOR REGISTRATION!" << endl;
        }
        if (age < 18 || lisence == 'n')
        {
            cout << "COSTUMER IS NOT CLEAR.CAR CAN NOT BE GRANTED!" << endl;
        }
    }
}
void costumermenu()
{
    cout << "1.Rent A Car" << endl;
    cout << "2.Check Availability" << endl;
    cout << "3.Check Price" << endl;
    cout << "4.View Car " << endl;
    cout << "5.View Profile " << endl;
    cout << "6.Compare Price" << endl;
    cout << "Select any option:";
    cin >> option2;
    if (option2 == 1)
    {
        cout << "********************RENT A CAR********************" << endl;
        cout << endl;
        cout << "WHICH CAR YOU WANT TO TAKE ON RENT?" << endl;
        cin >> rentcar;
        cout << "FOR HOW MANY DAYS YOU WANT TO KEEP IT";
        cin >> days;
        for (int i = 0; i < 6; i++)
        {
            cout << "car name = " << car[i] << " , car company = " << company[i] << " , car price = " << price[i] << endl;
        }
        for (int i = 0; i < 6; i++)
        {
            if (rentcar == car[i])
            {
                pricerent = days * price[i];
                cout << "THE PRICE FOR " << car[i] << " for " << days << " rent is " << pricerent << endl;
            }
        }
    }
    if (option2 == 2)
    {
        cout << "********************Check Availability********************" << endl;
        cout << endl;
        cout << "THE AVAILABLE CARS ARE :" << endl;
        for (int i = 0; i < 6; i++)
        {
            cout << "car name = " << car[i] << " , car company = " << company[i] << " , car price = " << price[i] << endl;
        }
    }
    if (option2 == 3)
    {
        cout << "********************CHECK PRICE********************" << endl;
        cout << endl;
        for (int i = 0; i < 6; i++)
        {
            cout << "price for " << car[i] << " is " << price[i] << endl;
        }
    }
    if (option2 == 4)
    {
        cout << "********************VIEW CARS********************" << endl;
        cout << endl;

        for (int i = 0; i < 6; i++)
        {
            cout << "car name = " << car[i] << endl;
        }
    }
    if (option2 == 5)
    {
        cout << "********************VIEW PROFILE********************" << endl;
        cout << endl;
    }
    if (option2 == 6)
    {
        cout << "********************COMPARE PRICE********************" << endl;
        cout << endl;
        cout << "Which cars you want to compare?" << endl;
        cin >> compcar1;
        for (int i = 0; i < 6; i++)
        {
            if (compcar1 == car[i])
            {
                cout << "price of " << compcar1 << " is " << price[i];
            }
            if (compcar2 == car[i])
            {
                cout << "price of " << compcar2 << " is " << price[i];
            }
        }
    }
}
void generateColors()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    // you can loop k higher to see more color choices

    int k = 11;
    SetConsoleTextAttribute(hConsole, k);
    // cout << k;
}
