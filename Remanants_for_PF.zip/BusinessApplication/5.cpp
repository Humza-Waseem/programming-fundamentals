#include <iostream>
#include <fstream>
#include <windows.h>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
using namespace std;

// funtions decleration

void logo();
string userNames[100];
string passwords[100];
string roles[100];
int userCount = 0;
bool signIn(string userName, string password);
bool isValidUsername(string userName);
void signUpArray(string userName, string password, string role);
void storeInFile(string userName, string password, string role);
int takeChoice();
void viewUsers();
void readDataFromFile();
void adminMenu(string car, string company, int price);
void costumerMenu(string car, string company, int price);

// Global Variables
int carArraySize = 100;
string car[carArraySize];
string company[carArraySize];
int price[carArraySize];

main()
{

    logo();
    readDataFromFile();
    bool decision;
    string userName;
    string password;
    string role;
    int choice = 4;
    while (choice != 0)
    {
        choice = takeChoice();
        if (choice == 1)
        {
            system("Cls");
            cout << "Enter your username: ";
            cin >> userName;
            cout << "Enter your password: ";
            cin >> password;
            cout << "Enter your Role: ";
            cin >> role;
            decision = isValidUsername(userName);
            if (decision == true)
            {
                signUpArray(userName, password, role);
                storeInFile(userName, password, role);

                cout << "User Created Successfully" << endl;
            }
            else
            {
                cout << "Username already exists" << endl;
            }
        }
        else if (choice == 2)
        {
            system("Cls");
            cout << "Enter your username: ";
            cin >> userName;
            cout << "Enter your password: ";
            cin >> password;
            decision = signIn(userName, password);
            if (decision == true)
            {
                cout << "Login Successful" << endl;
                system("Cls");
                if (role == "admin" || role == "Admin" || role == "ADMIN")
                {
                    adminMenu(car[carArraySize], company[carArraySize], price[carArraySize]);
                }
                else if (role == "costumer" || role == "Costumer" || role == "COSTUMER")
                {
                    costumerMenu(car[carArraySize], company[carArraySize], price[carArraySize]);
                }
            }
            else
            {
                system("Color 04");
                cout << "Invalid Credentials" << endl;
            }
        }
        else if (choice == 3)
        {
            viewUsers();
        }
    }
}
bool signIn(string userName, string password)
{
    bool flag = false;
    for (int idx = 0; idx < userCount; idx++)
    {
        if (userNames[idx] == userName && passwords[idx] == password)
        {
            flag = true;
            break;
        }
    }
    return flag;
}
bool isValidUsername(string userName)
{
    bool flag = true;
    for (int idx = 0; idx < userCount; idx++)
    {
        if (userNames[idx] == userName)
        {
            flag = false;
            break;
        }
    }
    return flag;
}
void signUpArray(string userName, string password, string role)
{
    userNames[userCount] = userName;
    passwords[userCount] = password;
    roles[userCount] = role;
    userCount++;
}
void storeInFile(string userName, string password, string role)
{
    fstream file;
    file.open("users.txt", ios::app);
    file << userName << endl;
    file << password << endl;
    file << role << endl;
    file.close();
}
int takeChoice()
{
    int choice;
    cout << "01. SignUp User" << endl;
    cout << "02. SignIn User" << endl;
    cout << "03. View Users" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice >  ";
    cin >> choice;
    return choice;
}
void viewUsers()
{
    cout << "Usernames"

         << "\t\t"
         << "Passwords" << endl;
    cout << "_____________"
         << "\t\t"
         << "_______________"
         << endl;
    for (int idx = 0; idx < userCount; idx++)
    {
        cout << userNames[idx] << "\t\t\t" << passwords[idx] << endl;
    }
    cout << endl;
}
void readDataFromFile()
{
    string username;
    string password;
    string role;
    fstream file;
    file.open("users.txt", ios::in);
    while (getline(file, username) && getline(file, password) && getline(file, role))
    {
        userNames[userCount] = username;
        passwords[userCount] = password;
        roles[userCount] = role;
        userCount++;
    }
    file.close();
}
void logo()

{

    cout << "  ###     #####  #####       #####    ######    ##     ###   ########" << endl;
    cout << " #   #    #   #  #  #        #  #     #         ##     #       ###" << endl;
    cout << " #        #####  # #         # #      ######    #  #   #        #" << endl;
    cout << " #   #    #   #  #  #        #  #     #         #    # #        #" << endl;
    cout << "  ###     #   #  #   #       #   #    ######  ###     ##        #" << endl;
}