#include <iostream>
#include <fstream>
#include <windows.h>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
using namespace std;

// funtions decleration

void logo();
string userNames[100];
string passwords[100];
string roles[100];
int userCount = 0;
bool signIn(string userName, string password);
bool isValidUsername(string userName);
void signUpArray(string userName, string password, string role);
void storeInFile(string userName, string password, string role);
int takeChoice();
void viewUsers();
void readDataFromFile();
void adminMenu(string car, string company, int price);
void costumerMenu(string car, string company, int price);

void storeCars();
void readCarData();
// Global variables
int option2;
int option3;

main()
{
    int carArraySize = 100;
    // car variables
    string car[carArraySize];
    string company[carArraySize];
    int price[carArraySize];

    logo();
    readDataFromFile();
    bool decision;
    string userName;
    string password;
    string role;
    int choice = 4;
    while (choice != 0)
    {
        choice = takeChoice();
        if (choice == 1)
        {
            system("Cls");
            cout << "Enter your username: ";
            cin >> userName;
            cout << "Enter your password: ";
            cin >> password;
            cout << "Enter your Role: ";
            cin >> role;
            decision = isValidUsername(userName);
            if (decision == true)
            {
                signUpArray(userName, password, role);
                storeInFile(userName, password, role);

                cout << "User Created Successfully" << endl;
            }
            else
            {
                cout << "Username already exists" << endl;
            }
        }
        else if (choice == 2)
        {
            system("Cls");
            cout << "Enter your username: ";
            cin >> userName;
            cout << "Enter your password: ";
            cin >> password;
            decision = signIn(userName, password);
            if (decision == true)
            {
                cout << "Login Successful" << endl;
                system("Cls");
                if (role == "admin" || role == "Admin" || role == "ADMIN")
                {
                    adminMenu(car[carArraySize], company[carArraySize], price[carArraySize]);
                }
                else if (role == "costumer" || role == "Costumer" || role == "COSTUMER")
                {
                    costumerMenu(car[carArraySize], company[carArraySize], price[carArraySize]);
                }
            }
            else
            {
                system("Color 04");
                cout << "Invalid Credentials" << endl;
            }
        }
        else if (choice == 3)
        {
            viewUsers();
        }
    }
}
bool signIn(string userName, string password)
{
    bool flag = false;
    for (int idx = 0; idx < userCount; idx++)
    {
        if (userNames[idx] == userName && passwords[idx] == password)
        {
            flag = true;
            break;
        }
    }
    return flag;
}
bool isValidUsername(string userName)
{
    bool flag = true;
    for (int idx = 0; idx < userCount; idx++)
    {
        if (userNames[idx] == userName)
        {
            flag = false;
            break;
        }
    }
    return flag;
}
void signUpArray(string userName, string password, string role)
{
    userNames[userCount] = userName;
    passwords[userCount] = password;
    roles[userCount] = role;
    userCount++;
}
void storeInFile(string userName, string password, string role)
{
    fstream file;
    file.open("users.txt", ios::app);
    file << userName << endl;
    file << password << endl;
    file << role << endl;
    file.close();
}
int takeChoice()
{
    int choice;
    cout << "01. SignUp User" << endl;
    cout << "02. SignIn User" << endl;
    cout << "03. View Users" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice >  ";
    cin >> choice;
    return choice;
}
void viewUsers()
{
    cout << "Usernames"

         << "\t\t"
         << "Passwords" << endl;
    cout << "_____________"
         << "\t\t"
         << "_______________"
         << endl;
    for (int idx = 0; idx < userCount; idx++)
    {
        cout << userNames[idx] << "\t\t\t" << passwords[idx] << endl;
    }
    cout << endl;
}
void readDataFromFile()
{
    string username;
    string password;
    string role;
    fstream file;
    file.open("users.txt", ios::in);
    while (getline(file, username) && getline(file, password) && getline(file, role))
    {
        userNames[userCount] = username;
        passwords[userCount] = password;
        roles[userCount] = role;
        userCount++;
    }
    file.close();
}
void logo()

{

    cout << "  ###     #####  #####       #####    ######    ##     ###   ########" << endl;
    cout << " #   #    #   #  #  #        #  #     #         ##     #       ###" << endl;
    cout << " #        #####  # #         # #      ######    #  #   #        #" << endl;
    cout << " #   #    #   #  #  #        #  #     #         #    # #        #" << endl;
    cout << "  ###     #   #  #   #       #   #    ######  ###     ##        #" << endl;
}
void adminMenu(string car, string company, int price, int carArraySize)
{

    cout << "**********************************" << endl;
    cout << "*                                *" << endl;
    cout << "*           ADMIN MENU           *" << endl;
    cout << "*                                *" << endl;
    cout << "**********************************" << endl
         << endl;
    cout << "1. Add cars" << endl;
    cout << "2. View Cars" << endl;
    cout << "3. Check availability " << endl;
    cout << "4. Remove Car" << endl;
    cout << "5. Check Documents" << endl;
    cout << "6. Returning A Car" << endl;
    cout << "7. EXIT" << endl
         << endl;
    cout << "Select any option:";
    cin >> option2;

    fstream file;
    for (int i = 0; i < carArraySize; i++)
    {
        while (getline(file, car[i]) && getline(file, company[i]))
        {
            file.open("cars.txt", ios::in);
            file << car[i] << endl;
            file << company[i] << endl;
            file << price[i] << endl;
        }
    }
    file.close();

    if (option2 == 1)
    {

        char choice;
        cout << "*****************ADD CARS********************" << endl
             << endl;
        // readCarData(company, price, car);
        bool choice2 = true;

        while (choice2 == true)
        {

            int i = 0;
            string cars;
            string companys;
            int prices;
            cout << "Enter the Name of Car You Want TO Enter: ";
            cin >> cars;
            cout << "Enter the Company of the Car: ";
            cin >> company[i];
            cout << "Enter the PRICE of Rent for 1 day: ";
            cin >> price[i];

            int check = 0;
            for (int x = 0; x <= i; x++)
            {
                if (cars == car[x])
                {
                    check++;
                    break;
                }
            }
            if (check == 0)
            {
                car[i] = cars;
                cout << "Car entered sucessfully!!" << endl;
                fstream file;
                file.open("cars.txt", ios::app);
                file << car[i] << endl;
                file << company[i] << endl;
                file << price[i] << endl;
                file.close();
                i = i + 1;
            }
            else if (check == 1)
            {
                cout << endl;
                cout << "CAR ALREADY EXISTS!!" << endl;
                cout << "press any key to continue...>>" << endl;
                getch();
                system("Cls");
                adminMenu();
            }

            cout << "DO YOU WANT TO CONTINUE ENTERING CARS ??        (y/n) ";
            cin >> choice;

            system("Cls");
            if (choice == 'y')
            {
                choice2 = true;
            }
            if (choice == 'n')
            {
                choice2 = false;
            }
        }
    }

    if (option2 == 2)
    {
        system("Cls");
        cout << "************VIEW CARS**************" << endl
             << endl;
        string cars;
        string companys;
        int prices;
        fstream file;
        int i = 0;
        file.open("cars.txt", ios::in);
        while (getline(file, cars) && getline(file, companys) && (file, prices))
        {
            car[i] = cars;
            cout << "car: " << car[i] << endl;

            company[i] = companys;
            cout << "company: " << company[i] << endl;

            price[i] = prices;
            cout << "price: " << price[i] << endl;
        }
        file.close();
        cout << "PRESS ANY KEY TO CONTINUE: " << endl;
        getch();
        system("Cls");

        adminMenu();
    }

    if (option2 == 3)
    {
        system("Cls");
        cout << "****************CHECK AVAILABILITY****************" << endl;

        string copycar;
        cout << "ENTER the CAR: ";
        cin >> copycar;
        bool flag2 = false;
        for (int i = 0; i < carArraySize; i++)
        {
            if (copycar == car[i])
            {
                cout << "CAR YOU WANT TO FIND IS: " << car[i] << endl
                     << endl;
                cout << "THE PRICE OF CAR  for 1 day of rent IS : " << price[i] << endl;
                flag2 = true;
            }
            else
            {
                continue;
            }
        }
        if (flag2 = false)
        {
            cout << "THE CAR YOU ENTER IS NOT AVAILABLE!!" << endl
                 << endl;
            cout << "PRESS ANY KEY TO CONTINUE:" << endl;
            getch();
            adminMenu();
        }

        if (flag2 = true)
        {
            cout << "______CAR IS AVAILABLE_____" << endl
                 << endl;
            cout << "PRESS ANY KEY TO CONTINUE:";
            getch();
            system("Cls");
            adminMenu();
        }
    }
    if (option2 == 4)
    {
        system("Cls");
        cout << "****************REMOVE CAR******************" << endl;
    }
    if (option2 == 5)
    {
        system("Cls");
        cout << "******************CHECK DOCUMENTS********************" << endl;

        char age;
        char license;
        cout << "Is the COSTUMER above 18??   (y/n)" << endl;
        cin >> age;
        cout << "Does the COSTUMER possess a License??    (y/n)" << endl;
        cin >> license;
        if ((age == 'y' || age == 'Y') && (license == 'y' || license == 'Y'))
        {
            // system("Color 0A");
            cout << "______________________" << endl;
            cout << "COSTUMER is ELEGIBLE !!" << endl;
            cout << "______________________" << endl;
            cout << "Press Any Key To Continue: "
                 << endl;
            system("Cls");
            adminMenu();
        }
        else
        {
            // system("Color E4");
            cout << "___________________________" << endl;
            cout << "COSTUMER IS NOT ELIGIBLE !!" << endl;
            cout << "___________________________" << endl;

            cout << "Press Any Key To Continue: "
                 << endl;
            getch();
            system("Cls");
            adminMenu();
        }
    }
    if (option2 == 6)
    {
        system("Cls");
        char returnc;
        cout << "Has the Costumer returned the Car??      (y/n)" << endl;
        cin >> returnc;

        if (returnc == 'y')
        {
            cout << "COSTUMER IS CLEARED!!" << endl;
            cout << "Press Any Key To Continue: "
                 << endl;
            adminMenu();
        }
        if (returnc == 'n')
        {
            cout << "COSTUMER IS NOT CLEARED!!" << endl;
            cout << "Press Any Key To Continue: "
                 << endl;
            adminMenu();
        }
        if (returnc != 'n' && returnc != 'y')
        {
            cout << "INVALID OPTION TRY AGAIN!! " << endl;
            cout << "Press Any Key To Continue: "
                 << endl;
            adminMenu();
        }
    }
}

void costumerMenu(string car, string company, int price)
{
    cout << "**********************************" << endl;
    cout << "*                                *" << endl;
    cout << "*         COSTUMER MENU          *" << endl;
    cout << "*                                *" << endl;
    cout << "**********************************" << endl
         << endl;

    cout << "1. Rent A Car" << endl;
    cout << "2. Check Availability" << endl;
    cout << "3. Check Price" << endl;
    cout << "4. View Car " << endl;
    cout << "5. View Profile " << endl;
    cout << "6. Compare Price" << endl;
    cout << "7. EXIT" << endl
         << endl;
    cout << "Select any option:";
    cin >> option3;
    if (option3 == 1)
    {
        string rentcar;
        int days;
        int pricerent = 0;
        cout << "********************RENT A CAR********************" << endl;
        cout << endl;
        cout << "WHICH CAR YOU WANT TO TAKE ON RENT?" << endl;
        cin >> rentcar;
        cout << "FOR HOW MANY DAYS YOU WANT TO KEEP IT";
        cin >> days;

        // }
        for (int i = 0; i < 10; i++)
        {
            if (rentcar == car[i])
            {
                pricerent = days * price[i];
                cout << "THE PRICE of " << car[i] << " for " << days << " rent is " << pricerent << endl;
            }
        }
    }
}
if (option3 = 2)
{
    cout << "***************CHECK AVAILABILITY*******************" << endl
         << endl;
}
if (option3 = 3)
{
    cout << "***************CHECK PRICE******************" << endl
         << endl;

    cout << endl;
    // for (int i = 0; i < 8; i++)
    // {
    //     cout << "price for " << car[i] << " is " << price[i] << endl;
    // }
}
if (option3 = 4)
{
    // cout << "****************VIEW PRICE*******************" << endl;
    // for (int i = 0; i < 8; i++)
    // {
    //     cout << "price: " << price[i];
    // }
}
if (option3 = 5)
{
    cout << "******************VIEW PROFILE*****************" << endl;
}
if (option3 = 6)
{
    cout << "*******************COMPARE PRICE*********************" << endl;
}
}
// void readCarData(string car, string company, int price)
// {
//     fstream file;

//     file.open("cars.txt", ios::in);
//     int i = 0;
//     while (getline(file, car) && getline(file, company))
//     {

//         car[i] == cars;

//         company[i] = company;
//         // price[i] = price;
//         i++;
//     }
//     file.close();
// }
