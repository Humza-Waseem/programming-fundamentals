#include <iostream>
#include <fstream>
#include <windows.h>
using namespace std;
string userNames[100];
string passwords[100];
int userCount = 0;
bool signIn(string userName, string password);
bool isValidUsername(string userName);
void signUpArray(string userName, string password);
void storeInFile(string userName, string password);
int takeChoice();
void viewUsers();
void readDataFromFile();
void adminmenu();
void logo();

// GLOBAL VARIABLES
int option1;

// string cars[20] = {"corolla", "gtr", "civic", "city", "cultus", "supra", "vigo"};
// string company[20] = {"toyota", "honda", "honda", "honda", "suzuki", "toyota", "toyota"};
main()
{
    logo();
    readDataFromFile();
    bool decision;
    string userName;
    string password;
    string role;
    int choice = 4;
    while (choice != 0)
    {

        choice = takeChoice();
        if (choice == 1)
        {
            cout << "Enter your username: ";
            cin >> userName;
            cout << "Enter your password: ";
            cin >> password;
            cout << "Enter your ROLE:";
            cin >> role;
            decision = isValidUsername(userName);
            if (decision == true)
            {
                signUpArray(userName, password);
                storeInFile(userName, password);
                cout << "User Created Successfully" << endl;
                if (role == "admin")
                {
                }
            }
            else
            {
                cout << "Username already exists" << endl;
            }
        }
        else if (choice == 2)
        {
            cout << "Enter your username: ";
            cin >> userName;
            cout << "Enter your password: ";
            cin >> password;
            cout << "ENTER YOUR ROLE:";
            cin >> role;
            decision = signIn(userName, password);
            if (decision == true)
            {
                cout << "Login Successful" << endl;
                if (role == "admin")
                {
                    adminmenu();
                }
            }
            else
            {
                cout << "Invalid Credentials" << endl;
            }
        }
        else if (choice == 3)
        {
            system("Cls");
            viewUsers();
        }
    }
}
bool signIn(string userName, string password)
{
    bool flag = false;
    for (int idx = 0; idx < userCount; idx++)
    {
        if (userNames[idx] == userName && passwords[idx] == password)
        {
            flag = true;
            break;
        }
    }
    return flag;
}
bool isValidUsername(string userName)
{
    bool flag = true;
    for (int idx = 0; idx < userCount; idx++)
    {
        if (userName[idx] == userName)
        {
            flag = false;
            break;
        }
    }
    return flag;
}
void signUpArray(string userName, string password)
{
    userNames[userCount] = userName;
    passwords[userCount] = password;
    userCount++;
}
void storeInFile(string userName, string password)
{
    fstream file;
    file.open("users.txt", ios::app);
    file << userName << endl;
    file << password << endl;
    file.close();
}
int takeChoice()
{
    int choice;
    cout << "01. SignUp User" << endl;
    cout << "02. SignIn User" << endl;
    cout << "03. View Users" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice >  ";
    cin >> choice;
    return choice;
}
void viewUsers()
{
    cout << "Usernames"
         << "\t\t"
         << "passwords" << endl;
    cout << "_____________"
         << "   "
         << "_____________" << endl
         << endl;
    for (int idx = 0; idx < userCount; idx++)
    {
        cout << userNames[idx] << "\t\t" << passwords[idx] << endl;
    }
}
void readDataFromFile()
{
    string username;
    string password;
    fstream file;
    file.open("users.txt", ios::in);
    while (getline(file, username) && getline(file, password))
    {
        userNames[userCount] = username;
        passwords[userCount] = password;
        userCount++;
    }
    file.close();
}
void adminmenu()
{
    cout << "********************ADMIN MENU********************" << endl;
    cout << "1.Add cars" << endl;
    cout << "2.Check Requests" << endl;
    cout << "3.View Custumer" << endl;
    cout << "4.Check availability " << endl;
    cout << "5.Remove Car" << endl;
    cout << "6.Check Documents" << endl;
    cout << "Select any option:";
    cin >> option1;
    system("Cls");
    if (option1 == 1)
    {
        cout << "********************ADD CARS********************" << endl;
        cout << endl;

        cout << "Enter Name of car: ";
        cin >> cars[7];
        cout << "Enter Company: ";
        cin >> company[7];
        // cout << "Enter Price: ";
        // cin >> prices;
        int i;
        for (i = 0; i < 5; i++)
        {
            if (cars[7] == cars[i])
            {
                cout << "CAR ALREADY ENTERED";
            }
        }
    }
}

void logo()

{

    cout << "  ###     #####  #####       #####    ######    ##     ###   ########" << endl;
    cout << " #   #    #   #  #  #        #  #     #         ##     #       ###" << endl;
    cout << " #        #####  # #         # #      ######    #  #   #        #" << endl;
    cout << " #   #    #   #  #  #        #  #     #         #    # #        #" << endl;
    cout << "  ###     #   #  #   #       #   #    ######  ###     ##        #" << endl;
}