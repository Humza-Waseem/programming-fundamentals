#include<iostream>
#include<windows.h>
using namespace std;
main()
{
system("color 02");
cout<<"This is my program"<<endl;
}