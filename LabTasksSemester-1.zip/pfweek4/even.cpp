#include<iostream>
using namespace std;
 void checkifeven(int a);
main(){
  int a;
  cout <<"enter the num";
  cin>>a;
checkifeven(a)}
  void checkifeven(int a){
  if(a%2==0){
  cout<<"even";
}}
if (a%2!=0)
  { 
  cout<<"odd";
}
   