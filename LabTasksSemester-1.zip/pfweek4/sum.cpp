#include <iostream>
using namespace std;

main(){
int number1,number2,number3,number4,sum;
cout<<"enter 1st num:";
cin>>number1;
cout<<"enter 2nd num:";
cin>>number2;
sum=number1+number2;
cout<<"sum="<<sum<<endl;


int number5,number6;
cout<<"enter 1st num:";
cin>>number3;
cout<<"enter 2nd num:";
cin>>number4;
sum=number3+number4;
cout<<"sum="<<sum<<endl;



cout<<"enter 1st num:";
cin>>number5;
cout<<"enter 2nd num:";
cin>>number6;
sum=number5+number6;
cout<<"sum="<<sum;


}