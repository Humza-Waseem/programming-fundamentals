#include <iostream>
using namespace std;
void displaydetails(string name,int marks,float agg,char section){
cout<<"your name is :"<<name<<endl;
cout<<"your marks are:"<<marks<<endl;
cout<<"your aggregate is:"<<agg<<endl;
cout<<"your sectionis :"<<section<<endl;

}
main()
{
string name;
int marks;
float agg;
char section;
cout<<"enter your name:";
cin>> name;
cout<<"enter your marks:";
cin >>marks;
cout<<"enter your aggregate";
cin>>agg;
cout<<"enter your section";
cin>>section;



}





