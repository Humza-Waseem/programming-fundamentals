#include <iostream>
using namespace std;
void isEligible(int age);

main()
{
int age;
cout<<"enter your age";
cin>>age;     }
void isEligible(int age)  
{
if(age>=18)
{ 
  cout<<"eligible";  
}
                                            
if (age<18)
{
  cout<<"not eligible";
}
}


   
  