#include<iostream>
using namespace std;
main()
{
int dollars;
int rupees;
int result;
rupees=200;
cout<<"enter the number of dollars";
cin>>dollars;
result=rupees*dollars;
cout<<"total money is:"<<result;
}