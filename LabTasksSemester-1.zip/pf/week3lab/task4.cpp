#include<iostream>
using namespace std;
main()
{ 
float lenght;
float width;
float area;
cout<<"the lenght of rectangle is:";
cin>>lenght;
cout<<"the width is:";
cin>>width;
area=lenght*width;
cout<<"area is ="<<area;
}
