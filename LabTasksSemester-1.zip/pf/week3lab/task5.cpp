#include<iostream>
using namespace std;
main()
{ 
int charge;
int time;
int current;
cout<<"enter charge:";
cin>>charge;
cout<<"enter time:";
cin >>time;
current=charge/time;
cout<<"current is"<<current;
}