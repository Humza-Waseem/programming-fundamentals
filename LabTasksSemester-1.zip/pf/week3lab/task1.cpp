#include<iostream>
using namespace std;
main()
{    
string name;
int rollno;
float aggregate;
char grade;
cout<<"ENTER name :";
cin>>name;
cout<<" ENTER rollno:";
cin>>rollno;
cout<<" ENTER aggregate :";
cin>>aggregate;
cout<<"ENTER grade :";
cin>>grade;
}