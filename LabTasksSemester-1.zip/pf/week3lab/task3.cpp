#include<iostream>
using namespace std;
main()
{ 
float weightlb;
float weightkg;
float val=0.45;
cout<<"enter the weight in lbs:";
cin>>weightlb;
weightkg=weightlb*val;
cout<<"weight in kg is:"<<weightkg;
}

