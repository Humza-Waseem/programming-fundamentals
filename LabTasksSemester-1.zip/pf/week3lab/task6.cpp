#include<iostream>
using namespace std;
main()
{ 
string name;
float matric;
float intermediate;
float ecat;
float aggregate;
cout<<"enter the name";
cin>>name;
cout<<"enter matric";
cin>>matric;
cout<<"enter intermediate";
cin>>intermediate;
cout<<"enter ecat";
cin>>ecat;
aggregate=(50/100)*ecat+(40/100)*intermediate+(10/100)*matric;
cout<<"aggregate is :"<<aggregate;
}

