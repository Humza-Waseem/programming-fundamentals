#include<iostream>
using namespace std;
main()
{ 
   int megabytes;
   int bits;
  
   cout<<"enter the megabytes:";
   cin>>megabytes;
   bits=1024*1024*8*megabytes;
   cout<<"no of bits are"<<bits;
}