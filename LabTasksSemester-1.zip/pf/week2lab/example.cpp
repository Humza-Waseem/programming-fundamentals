#include<iostream>
using namespace std;
main()
{
   float aggregate;
   aggregate=82.53

cout<<aggregate;




}