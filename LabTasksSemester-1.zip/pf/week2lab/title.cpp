#include<iostream>
#include<windows.h>
using namespace std;
main()
{
system("color 02");

}