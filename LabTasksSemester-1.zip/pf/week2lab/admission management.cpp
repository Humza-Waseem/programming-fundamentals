#include <iostream>
using namespace std;
main()
{
cout<<"   ***************************************************      "<<endl;
cout<<"   *                                                 *       "<<endl;
cout<<"   *                University Admission             *        "<<endl;
cout<<"   *                 Management System               *        "<<endl;
cout<<"   *                                                 *        "<<endl;
cout<<"   *                                                 *        " <<endl;
cout<<"   ***************************************************        "<<endl;

}