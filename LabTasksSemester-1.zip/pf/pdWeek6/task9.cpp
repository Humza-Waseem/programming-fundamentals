#include <iostream>
#include <windows.h>
using namespace std;
void printMaze();
void gotoxy(int x, int y);
void Pacman(int x, int y);
void Ghost(int x, int y);
void getCharAtxy(int x, int y);
void clear(int x, int y, char p);
main()
{
    int gx = 1;
    int gy = 1;
    string direction = "right";
    char previouschar = ' ';
    system("cls");
    Ghost(gx, gy);
    while (true)
    {
        Sleep(100);
    }
}

// move ghost functionality

if (direction == "right")
{
    char nextlocation = getCharAtxy(gx + 1, gy);
    if (nextlocation == "%")
    {
        direction = "left";
    }
    else if
    {
        (nextlocation == ' ' || nextlocation == '.')
            ckear(gx, gy, previousChar);
        gx = gx + 1;
        previousChar = nextlocation;
        Ghost(gx, gy);
    }
    if (direction == "left")
    {
        char nextlocation = getCharAtxy(gx - 1, gy);
        if (nextlocation == '%')
        {
            direction = "right";
        }
        else if (nextlocation == ' ' || nextlocation == '.')
        {
            clear(gx, gy, previousChar);
            gx = gx - 1;
            previousChar = nextlocation;
            Ghost(gx, gy);
        }
    }
}