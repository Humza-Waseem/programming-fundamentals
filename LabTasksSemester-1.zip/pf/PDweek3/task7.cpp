#include<iostream>
using namespace std;
main()
{ 
string name;
float adultprice,childprice;
float adsold,chsold;
float percentage;
float total;
float donation;
cout<<"enter movie name:";
cin>>name;
cout<<"enter adult ticket price:";
cin>>adultprice;
cout<<"enter child ticket price:";
cin>>childprice;
cout<<"enter number of adult ticket sold:";
cin>>adsold;
cout<<"enter number of child ticket sold:";
cin>>chsold;
cout<<"enter percentage to donate:";
cin>>percentage;
total=(adultprice*adsold)+(childprice*chsold);
cout<<"total amout generated"<<total<<endl;
donation=total-(percentage/100*total);
cout<<"amount after donation:"<<donation;
}







