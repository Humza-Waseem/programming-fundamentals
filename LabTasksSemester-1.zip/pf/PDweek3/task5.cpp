#include<iostream>
using namespace std;
main()
{ 
float weight;
float days;
cout<<"enter weight that u want to lose";
cin>>weight;
days=weight*15;
cout<<"it will take you  "<<days<<"  days to lose" <<weight<<" kg ";
}

