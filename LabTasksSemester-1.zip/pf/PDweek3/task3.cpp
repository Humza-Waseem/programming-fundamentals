#include<iostream>
using namespace std;
main()
{ 
int vin;
int acceleration;
int time;
float vf;
cout<<"enter the initial velocity:";
cin>>vin;
cout<<"enter acceleration:";
cin>>acceleration;
cout<<"enter time";
cin>>time;
vf=(acceleration*time)+vin;
cout<<"final velocity is ="<<vf;
}
