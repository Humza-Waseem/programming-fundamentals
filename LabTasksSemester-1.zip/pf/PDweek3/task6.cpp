#include<iostream>
using namespace std;
main()
{ 
int size,cost;
float area;
float costpp;
float costpsq;
cout<<"enter bag size in pound:";
cin>>size;
cout<<"enter cost of the bag:";
cin>>cost;
cout<<"enter area covered by each bag in square feet:";
cin>>area;
costpp=cost/size;
cout<<"cost of the fertilizer per pound:"<<costpp<<endl;
costpsq=cost/area;
cout<<"cost of fertilizing the area per square feet:"<<costpsq;
}



