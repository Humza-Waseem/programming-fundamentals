#include<iostream>
using namespace std;
main()
{ 
int num1,num2,num3;
int avg;

cout<<"enter marks of student 1:";
cin>>num1;
cout<<"enter marks of student 2:";
cin>>num2;
cout<<"enter marks of student 3:";
cin>>num3;
avg=num1+num2+num3/3;
cout<<"average of class is :"<<avg;
l;
}