#include<iostream>
using namespace std;
main()
{ 
string name;
float marks1,marks2,marks3,marks4,marks5;
float percentage;
cout<<"enter name";
cin>>name;
cout<<"enter subject 1 marks:";
cin>>marks1;
cout<<"enter subject 2 marks:";
cin>>marks2;
cout<<"enter subject 3 marks:";
cin>>marks3;
cout<<"enter subject 4 marks:";
cin>>marks4;
cout<<"enter subject 5 marks:";
cin>>marks5;
percentage=(marks1+marks2+marks3+marks4+marks5)/500*100;
cout<<"total percentage is:"<<percentage;
}

