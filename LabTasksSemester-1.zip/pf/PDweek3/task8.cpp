#include<iostream>
using namespace std;
main()
{ 
float vegpricekg;
float fruitpricekg;
int totalkgveg;
int totalkgfruit;
float totalveg;
float totalfruit;
cout<<"vegetable price per kg:";
cin>>vegpricekg;
cout<<"fruit price per kg:";
cin>>fruitpricekg;
cout<<"total kg vegetables";
cin>>totalkgveg;
cout<<"total kg fruit";
cin>>totalkgfruit;
totalveg=vegpricekg*totalkgveg;
totalfruit=fruitpricekg*totalkgveg;
cout<<"total earning of veg"<<totalveg<<endl;
cout<<"total earning of fruit"<<totalfruit;
total earnin

}

