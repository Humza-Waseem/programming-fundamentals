#include<iostream>
using namespace std;
main()
{
int num1,num2,num3,num4,num5,num6,num7,num8,num9,num10,num11,num12,num13,num14,num15;
int add;
int mul;
int sub;
int result1,result2,finalresult;
cout<<"enter 1st number";
cin>>num1;
cout<<"enter2nd number";
cin>>num2;
cout<<"enter3rd number";
cin>>num3;
cout<<"enter 4th number";
cin>>num4;
cout<<"enter5th number";
cin>>num5;
cout<<"enter6th number";
cin>>num6;
cout<<"enter 7th number";
cin>>num7;
cout<<"enter 8th number";
cin>>num8;
cout<<"enter9th number";
cin>>num9;
cout<<"enter10th number";
cin>>num10;
cout<<"enter11th number";
cin>>num11;
cout<<"enter12th number";
cin>>num12;
cout<<"enter 13th number";
cin>>num13;
cout<<"enter 14th number";
cin>>num14;
cout<<"enter15th number";
cin>>num15;
add=(num1+num2+num3+num4+num5);
mul=(num6+num7+num8+num9+num10);
sub=(num11+num12+num13+num14+num15);
result1=add+mul;
result2=result1-sub;
finalresult=result2;
cout<<"finalresult== "<< finalresult;



}






