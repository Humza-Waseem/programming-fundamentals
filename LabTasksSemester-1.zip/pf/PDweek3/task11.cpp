#include<iostream>
using namespace std;
main()
{
int num,sum;
cout<<"enter 1st integer";
cin>>num;
cout<<"enter 2nd integer";
cin>>num;
cout<<"enter 3rd integer";
cin>>num;
cout<<"enter 4th integer";
cin>>num;
cout<<"enter 5th integer";
cin>>num;
sum=num;
cout<<"sum is ="<<sum;
}
