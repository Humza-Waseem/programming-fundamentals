#include<iostream>
using namespace std;
main()
{
int dd;
int mm;
int yy;
cout<<"age in days"<<endl;
cin>>dd;
cout<<"age in months"<<endl;
cin>>mm;
cout<<"age in years"<<endl;
cin>>yy;
int years;
years=2022-yy;
cout<<"your age in years is :"<<years;
}