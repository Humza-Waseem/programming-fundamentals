#include <fstream>
using namespace std;
main()
{
    fstream file;
    file.open("example.txt", ios::out);
    file << "this is sample ";
    file.close();
}