#include <iostream>
using namespace std;
main()
{
    int n;
    cout << "enter the no of elements:";
    cin >> n;
    int arr[n];
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        cout << "enter the number:";
        cin >> arr[i];
    }
    for (int i = 0; i < n; i++)
    {
        if (arr[i] < arr[i + 1] && arr[i + 1] > arr[i + 2])
        {
            cout << arr[i + 1];
        }
    }
}