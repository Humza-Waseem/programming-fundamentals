#include <iostream>
using namespace std;
main()
{
    int n;
    cout << "enter the size of array:";
    cin >> n;
    int mul;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cout << "enter the elements:";
        cin >> arr[i];
    }
    int sum = 0;
    for (int i = 0; i < n; i = i + 3)
    {
        mul = arr[i] * arr[i + 1] * arr[i + 2];
        sum = sum + mul;
    }
    cout << sum;
}