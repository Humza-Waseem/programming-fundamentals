#include <iostream>
using namespace std;
main()
{

    int miles[2] = {9, 9};
    int sum = 0;

    for (int i = 0; i < 2 - 1; i++)
    {
        if (miles[i] < miles[i + 1])
        {
            sum = sum + 1;
        }
    }
    cout << "there are " << sum << " progress days";
}