#include <iostream>
using namespace std;
main()
{
    int n;
    cout << "enter the length of length:";
    cin >> n;
    string arr[n];
    char letter;

    int count;
    for (int i = 0; i < n; i++)
    {
        cout << "enter the  arr";
        cin >> arr[i];
    }
    cout << "enter the character:";
    cin >> letter;
    int i = 0;
    while (arr[i] != '\0')
    {

        if (arr[i] == letter)
        {
            count = count + 1;
        }
        i++;
    }
    cout << count;
}
