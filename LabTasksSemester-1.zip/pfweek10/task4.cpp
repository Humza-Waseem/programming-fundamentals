#include <iostream>
using namespace std;
main()
{
}