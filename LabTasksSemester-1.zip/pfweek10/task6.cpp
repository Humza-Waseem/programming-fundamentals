#include <iostream>
using namespace std;
main()
{
    int n;
    int arr[n];
    cout << "enter the no of elements of array:";
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cout << "enter the element:";
        cin >> arr[i];
    }
}