#include <iostream>
using namespace std;
main()
{
    string name;
    int size = 0;
    cout << "enter the word:";
    cin >> name;
    for (int i = 0; name[i] != '\0'; i++)
    {
        size++;
    }
    for (int i = size; i >= 0; i--)
    {
        cout << name[i];
    }
}