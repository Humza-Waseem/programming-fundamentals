#include<iostream>
using namespace std;
main()
{     
  int num1,num2,num3,num4,num5,num6,num7,num8,num9,num10;
  float result;
  cout<<"enter first num";
  cin>>num1;
  cout<<"enter 2nd num";
  cin>>num2;
  cout<<"enter3rd num";
  cin>>num3;
  cout<<"enter4th num";
  cin>>num4;
  cout<<"enter5th num";
  cin>>num5;
  cout<<"enter 6th num";
  cin>>num6;
  cout<<"enter7th num"; 
  cin>>num7;
  cout<<"enter8th num";
  cin>>num8;
  cout<<"enter9th num";
  cin>>num9;
  cout<<"enter10th num";
  cin>>num10;
  result=(num1+num2+num8+num9)+(num6-num5)+(num7/num3)+(num4*num10);
  cout<<"result of expression is :"<<result;
}
 
  