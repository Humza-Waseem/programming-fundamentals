#include<iostream>
using namespace std;
main()
{
 float w;
 int g=10;
 float m;
 cout<<"what is the weight of body";
cin>>w;
 m=w/g;
cout<<"mass is :"<<m;
}
