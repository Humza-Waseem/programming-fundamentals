#include<iostream>
using namespace std;
main()
{ 
string name;
float matric;
float intermediate;
float ecat;
float aggregate;
cout<<"enter the name:";
cin>>name;
cout<<"enter matric:";
cin>>matric;
cout<<"enter intermediate:";
cin>>intermediate;
cout<<"enter ecat:";
cin>>ecat;
aggregate=(matric/1100.0*100*0.30)+(intermediate/1100.0*100*0.30)+(ecat/1100.0*100*0.40);
cout<<"aggregate is :"<<aggregate;
}

