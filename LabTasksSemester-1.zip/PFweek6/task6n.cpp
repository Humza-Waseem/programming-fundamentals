#include <iostream>
using namespace std;


main()
{
float k;
string period;

cout<<"ENTER THE NO OF KILOMETERS:";
cin>>k;
cout<<"ENTER THE PERIOD OF TIME:";
cin>>period;

float startingFee=0.70;
float taxiDay=0.79;
float taxiNight=0.90 ;
float busDN=0.09;
float trainDN=0.06;


float taxiDayf=startingFee + taxiDay*(taxiDay/k);
float taxiNightf=startingFee + taxiNight*(taxiNight/k);

float busDNf=busDN*(busDN/k);

float trainDNf=trainDN*(trainDN/k);

 
  cout<<"taxiday:"<<taxiDayf;
  cout<<"taxiNight:"<<taxiNightf;
  cout<<"busDNf:"<<busDNf;
  cout<<"trainDN:"<<trainDNf;

 /* if(period == "day" )
  {
   if(k>=20 || k>=100)
   {
  
    if(taxiDayf < taxiNightf && taxiDayf < busDNf && taxiDayf < trainDNf ) 
    {
     cout<<taxiDayf;
     }
     else if (taxiNightf<taxiDayf &&taxiNightf<busDNf && taxiNightf<trainDNf)
      {
        cout<<taxiNightf;
       }
      else if(busDNf<taxiDayf && busDNf<taxiNightf && busDNf<trainDNf)
       {
        cout<<busDNf;
        }
       else 
        {
          cout<<trainDNf;
         }
        }
        }      */
}