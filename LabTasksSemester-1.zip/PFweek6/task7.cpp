#include <iostream>
using namespace std;


main()
{
float coffeeS=0.50 , coffeeP=0.40 , coffeeV=0.45 , waterS=0.80 , waterP=0.70 , waterV=0.70 , beerS=1.20,beerP=1.15,beerV=1.10,sweetsS=1.45,sweetsP=1.30,sweetsV=1.35,peanutsS=1.60,peanutsP=1.50,peanutsV=1.55;

int n;
string city,prod;

cout<<"ENTER THE CITY NAME:";
cin>>city;
cout<<"ENTER THE PRODUCT NAME:";
cin>>prod;
cout<<"ENTER THE NUMBER OF PRODUCTS:";
cin>>n;

float cost;



  if(city == "varna" && prod == "coffee")
 
  {cost = n*coffeeV;
  cout<<cost;}
  
  if(city == "sofia" && prod == "coffee")
  
 { cost = n*coffeeS;
  cout<<cost;}

   if(city =="plovdiv" && prod == "coffee")
  {
  cost= n*coffeeP;
   cout<<cost;}
   if(city =="plovdiv" && prod =="water")
    
  {cost= n*waterP;
    cout<<cost;}
 
  

  

}
  





