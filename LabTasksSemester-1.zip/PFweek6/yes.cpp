#include<iostream>
using namespace std;
bool isSimilar(string name1,string name2,bool value);

main()
{
string name1,name2;
cout<<"ENTER THE FIRST NAME:";
cin>>name1;
 
cout<<"ENTER THE 2nd NAME:";
cin>>name2;

bool value;

value=bool isSimilar(name1,name2,value);
cout<<value;
}


bool isSimilar(string name1,string name2,bool value)
{

 if (name1==name2)
{
return value;
}
if (name1!=name2)
{
return value;
}
return 0;
}

