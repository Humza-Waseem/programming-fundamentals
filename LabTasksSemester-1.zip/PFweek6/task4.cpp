#include <iostream>
using namespace std;
string checktitle(int age,char gender);
main()
{
  char gender;
  int age;
cout<<"ENTER THE GENDER: ";
cin>>gender;
cout<<"ENTER THE AGE: ";
cin>>age;


checktitle(age,gender);
}
 
string checktitle(int age,char gender)
{
   if(gender=='m' && age>=16)
   {
    cout<<"MR.";
   }
  else if(gender=='m' && age < 16)
   {
   cout<<"MASTER";
   }
  else if(gender == 'f' && age >= 16)
   {
    cout<<"MS.";
   }
  else if(gender == 'f' && age < 16)
   {
    cout<<"MISS";
    }

return 0;
}
   
