#include <iostream>
using namespace std;
float discount(float amount,string day,string month);
float payable;
main()
{
 float amount;
 string day,month;


 cout<<"ENTER THE AMOUNT:";
 cin>>amount;
 
 cout<<"ENTER THE DAY:";
 cin>>day;
 
 cout<<"ENTER THE MONTH:";
 cin>>month;

payable=discount(amount,day,month);
cout<<payable;
}

float discount(float amount,string day,string month)
{
 float dis;

  if(day=="sunday" && month=="october")
  { 
   dis=(amount*10)/100;
   payable=amount-dis;
   return payable;
   }
  if(day!="sunday")
  { 
   cout<<"total amount:"<<amount;
  }
  
 return 0;
}