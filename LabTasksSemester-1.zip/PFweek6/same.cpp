#include <iostream>
using namespace std;
main()
{
 int a,b,c;
cout<<"ENTER FIRST NUMBER:";
cin>>a;
cout<<"ENTER 2ND NUMBER:";
cin>>b;
cout<<"ENTER 3RD NUMBER:";
cin>>c;

if(a==b && a==c)
 cout<<"yes";
if(a!=b && a!=c)
cout<<"no";

}