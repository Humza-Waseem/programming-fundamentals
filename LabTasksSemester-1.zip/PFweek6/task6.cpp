#include<iostream>
using namespace std;
main()
{ 
  string type;
  float rows,columns;
  float totalprice;
  
cout<<"ENTER THE SCREEN TYPE:";
cin>>type;
cout<<"ENTER THE NO OF ROWS:";
cin>>rows;
cout<<"ENTER THE NO OF COLUMNS:";
cin>>columns;

if(type=="premiere")
{

  

totalprice=12.00 * rows * columns;
cout<<"total price ="<<totalprice;
}

if(type=="normal")
{

totalprice=7.50 * rows * columns;
cout<<"total price ="<<totalprice;
}

if(type=="discount")
{
  
totalprice=5.00 * rows * columns;
cout<<"total price ="<<totalprice;
}
}



  