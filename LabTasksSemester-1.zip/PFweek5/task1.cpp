#include<iostream>
using namespace std;
int add(int num1, int num2);
float division(int number1,int number2);
main()
{
  int num1,num2;
  int result;
 float divide;
  
  cout<<"enter the first number";
  cin>>num1;
  cout<<"enter the 2nd number";
  cin>>num2;
   result = add(num1,num2);
  cout<<"sum:"<<result;
  divide = division(num1,num2);
  cout<<"div:"<<divide;
}
 
   int add(int num1,int num2)
  
 {
     int sum;
   sum=num1+num2;
   return sum;
  }
 
 float division(int num1,int num2)
{

 float divide;
 divide=num1/num2;
 return divide;
}