#include<iostream>
#include<cmath>
#include<windows.h>
using namespace std;

main()
{
 
int a,b,c,det;
float x1,x2;
a=5;
b=6;
c=1;
det=b*b-4*a*c;
x1=(-b-sqrt(det))/(2*a);
x2=(-b+sqrt(det))/(2*a);
cout<<"x in negative is :"<<x1<<endl;
cout<<"x in positive is :"<<x2;
}