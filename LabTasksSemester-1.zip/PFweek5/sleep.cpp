#include <iostream>
#include <windows.h>
using namespace std;
 
 int main()
{ 
 
int number1,number2;
cout<<"enter num1";
cin>>number1;
cout<<"enter num2";
cin>>number2;


cout<<"minimum number"<<min(number1,number2);
return 0;
}
