#include <iostream>
#include <windows.h>
#include <cmath>
using namespace std;
 
 int main()
{ 
 int num1,num2;
  
cout<<"entter number :";
cin>>num1;
cout<<"enter power :";
cin>>num2;
cout<<num1<<"  power "<<num2<<"is ="<<pow(num1,num2);  
return 0;
}
