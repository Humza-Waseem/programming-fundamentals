#include <iostream>
using namespace std;
main()
{
    int num;
    cout << "enter the number:";
    cin >> num;
    int num1, num2;
    num1 = num % 10;

    num2 = num / 10;
    num2 = num2 % 10;

    int num3;
    num3 = num / 100;
    num3 = num3 % 10;

    if (num1, num2, num3 == num)
        cout << "number is symmetrical";
    else
        cout << "number is not symmetrical";
}