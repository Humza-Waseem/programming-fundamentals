#include<iostream>
using namespace std;
 main()
{

 {
 int n, t, sum = 0, remainder;
cout<<"Enter an integer";
cin>>n;
t = n;
while (t != 0) 
{ remainder = t % 10; sum = sum + remainder; t = t / 10; }
printf("Sum of digits of"<<n " =" <<sum
return 0; }
