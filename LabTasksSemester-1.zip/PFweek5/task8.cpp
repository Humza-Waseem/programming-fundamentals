#include<iostream>
#include<cmath>
#include<windows.h>
using namespace std;


 main()
{
 float distance;
 float angle;
 float radians;
 float perpendicular;

     cout<<"enter the distance";
     cin>>distance;
     cout<<"enter the degrees";
     cin>>angle;
  radians = angle*0.0174;
  cout<<radians;


   

 perpendicular=tan(radians) * distance;
  cout<<"height is = "<<perpendicular;
}
