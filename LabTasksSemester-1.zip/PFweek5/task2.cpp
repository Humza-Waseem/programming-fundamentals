#include <iostream>
using namespace std;
string letter(char ch);


string statement;
main()
{

char ch;
cout<<"enter the character:";
cin>>ch;

statement=letter(ch);
}

string letter(char ch)
{
  
    if(ch=='a')
    {  
      cout<<"you have entered small letter "<<statement;
     }
     if (ch=='A')
     { 
      cout<<"you have entered capital letter "<<statement;
      }
    return statement;
}