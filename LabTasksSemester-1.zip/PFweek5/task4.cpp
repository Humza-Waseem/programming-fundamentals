#include <iostream>
using namespace std;
main ()
{
	int input;
	int sum;
	int digit1;
	int digit2;
	int digit3;
	int digit4;
	cout << "Enter Four Digit Number: ";
	cin >> input;              //1234
	digit1 = input%10;         //=4
	input = input-digit1;      // 1234-4=1230 
	digit2 = input%100;        //1230%100=30
	input = input-digit2;      //1230-30=1200
	digit2 = digit2/10;        //30/10=3
	digit3 = input%1000;       //1200%1000=200
	input = input-digit3;      //1200-200=1000
	digit3 = digit3/100;       //200/100=2
	digit4 = input%10000;      //1000%10000=1000
	digit4 = digit4/1000;      //1000/1000=1
	sum = digit1+digit2+digit3+digit4;  //1+2+3+4
	cout << "Sum: " << sum<<endl;
    
        if(sum%2==0)
        {
         cout<<"**number is evenish**";
        }
        if(sum%2!=0)
       {

       cout<<"**number is oddish**";
      }

}