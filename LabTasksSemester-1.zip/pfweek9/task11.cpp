#include <iostream>
using namespace std;
main()
{
    string name;
    char letter;
    cout << "enter the word:";
    cin >> name;
    cout << "enter the letter:";
    cin >> letter;
    int i = 0;
    while (name[i] != '\0')
    {
        i++;
    }
    if (name[i - 1] == letter)
    {
        cout << "letter found";
    }
    else
    {
        cout << "letter not found";
    }
}