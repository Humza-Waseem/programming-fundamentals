#include <iostream>
using namespace std;
main()
{
    cout << "something"
         << " ";
    cout << "is better than nothing";
}