#include <iostream>
using namespace std;
main()
{
    string arr;
    cout << "enter the word:";
    cin >> arr;
    int location = 0;
    for (int i = 0; arr[i] != '\0'; i++)
    {
        cout << "location of letter :" << arr[i] << ":is:" << location++ << endl;
    }
}