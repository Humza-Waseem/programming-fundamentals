#include <iostream>
using namespace std;
main()
{
    int value;
    int arr[value];
    cout << "enter the index value:";
    cin >> value;

    for (int i = 0; i < value; i++)
    {
        cin >> arr[i];
    }
}
