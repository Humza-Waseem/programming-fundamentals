#include <iostream>
using namespace std;
main()
{
    string arr;
    cout << "enter the string :";
    cin >> arr;
    int a = 0;
    for (int i = 0; arr[i] != '\0'; i++)
    {
        if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u')
        {
            a++;
        }
    }
    cout << a;
}