#include <iostream>
using namespace std;
main()
{
    string arr;
    cout << "enter the string";
    cin >> arr;
    for (int i = 0; arr[i] != '\0'; i++)
    {

        arr[i]++;
    }
    cout << arr;
}