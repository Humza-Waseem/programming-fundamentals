#include <iostream>
using namespace std;
main()
{
    int num;
    int arr1[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int arr2[9];
    // for (int i = 0; i < 9; i++)
    // {
    //     // cout << arr1[i] << "\t";
    // }
    cout << "Enter the number: ";
    cin >> num;
    for (int i = 0; i < 9; i++)
    {

        if (arr1[i] == num)            // num =4
        {
            for (int i = num; i < 9; i++)          //

            {
                // cout << arr1[i]; 
                arr2[i] = arr1[i];                    // 5,,6,7,8,9
            }
        }
    }

    for (int i = 0; i < num; i++)
    {
        // cout << arr1[i];
        arr2[i] = arr1[i];
    }
    cout << endl
         << endl;
    cout << "final answer is: " << endl;
    for (int i = 0; i < 9; i++)
    {
        cout << arr2[i + num] << " ";
    }
}