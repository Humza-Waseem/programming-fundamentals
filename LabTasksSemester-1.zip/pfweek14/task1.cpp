#include <iostream>
using namespace std;
void passingToFunction(int arr[3][3])
{
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j <= 2; j++)
        {
            cout << arr[i][j] << endl;
        }
    }
}
main()
{
    int arr[3][3] = {{1, 2, 3},
                     {4, 5, 6}};
    // cout << arr;
    passingToFunction(arr);
    // cout << arr[1][2];
}