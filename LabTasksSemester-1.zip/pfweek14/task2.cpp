#include <iostream>
using namespace std;
void average(int arr[], int size)
{
    int sum = 0;
    for (int i = 0; i < size; i++)
    {
        sum = sum + arr[i];
    }
    float avg = 0;
    avg = sum / size;
    cout << " AVERAGE = " << avg;
}
main()
{
    int size;
    cout << "Enter the size of Array:";
    cin >> size;
    int arr[size];
    for (int i = 0; i < size; i++)
    {
        cout << "Enter the element of array:";
        cin >> arr[i];
    }
    average(arr, size);
}