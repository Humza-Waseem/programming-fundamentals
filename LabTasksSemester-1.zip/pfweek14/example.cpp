#include <iostream>
using namespace std;
void swapValues(int &number1, int &number2)

{
    int temp = number1;
    number1 = number2;
    number2 = temp;
}
main()
{
    int num1 = 10;
    int num2 = 11;
    cout << num1 << endl;
    cout << num2 << endl;
    // int *p = &num;
    // num = 20;
    // cout << *p;
    swapValues(num1, num2);
    cout << " number1 == " << num1 << endl;
    cout << " number2 == " << num2;
}
