#include <iostream>
using namespace std;

int main()
{
    int num, digit, frequency = 0;

    cout << "Enter a number: ";
    cin >> num;

    cout << "Enter a digit: ";
    cin >> digit;

    while (num > 0)
    {
        if (num % 10 == digit)
        {
            frequency++;
        }
        num =num / 10;
    }

    cout << "The frequency of " << digit << " in the entered number is: " << frequency << endl;

    return 0;
}
