#include <iostream>
using namespace std;
main()
{
    int sum = 0, i;
    for (i = 0; i <= 5; i++)
    {
        sum = sum + i;
    }
    cout << "sum of first 5 natural numbers is:" << sum;
}
