#include <iostream>
using namespace std;
main()
{
    int sum = 0, i;
    for (i = 0; i <= 100; i++)
    {
        sum = sum + i;
    }
    cout << "sum of first 100 natural numbers is:" << sum;
}
