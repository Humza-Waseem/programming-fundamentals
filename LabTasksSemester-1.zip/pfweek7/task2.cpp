#include <iostream>
using namespace std;
void loop(int digit);
main()
{
    int digit;
    cout << "enter number:";
    cin >> digit;
    loop(digit);
}
void loop(int digit)
{
    int x = 0;
    while (digit != 0)
    {

        digit = digit / 10;
        x = x + 1;
    }
    cout << "the number of digits are:" << x;
}
