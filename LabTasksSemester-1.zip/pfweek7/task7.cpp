#include <iostream>
using namespace std;
int hcf(int number);
int 
main()
{
int number;
digitsum(number);

}
int digitsum(int number)
{
for( ;number <= 0; number++)

}
