#include <iostream>
using namespace std;
main()
{
    int num;
    cout << "enter the number:";
    cin >> num;
    while (num <= 0)
    {
        cout << "invalid number" << endl;
        cout << "enter a positive numbber" << endl;
        cin >> num;
    }
    cout << "correct! ";
}