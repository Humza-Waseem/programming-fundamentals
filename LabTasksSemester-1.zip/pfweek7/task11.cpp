#include <iostream>
using namespace std;
main()
{
    int num;
    cout << "enter a num:";
    cin >> num;
    for (int i = 1; i <= num; i++)
    {
        cout << i << endl;
    }
}