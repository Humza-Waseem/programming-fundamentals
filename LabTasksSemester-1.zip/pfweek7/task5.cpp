#include <iostream>
using namespace std;
void gcd(int a,int b,int num);
void lcm(int a,int b,int num);
main()
{
gcd(a,b);
lcm(a,b);


}
void gcd(int a,int b,int num)
{
    while()
    
 if( a % num == 0 && b % num == 0)
  {
     
  }

}
