#include <iostream>
using namespace std;
void loop(int l);
main()
{
    int l;

    loop(10);
}
void loop(int l)
{
    int previous = 0;
    int current = 1;
    int next;
    cout << "fibanocci series:" << previous << "," << current;

    for (int count = 1; count <= l - 2 ; count++)
    {
        next = previous + current;
        cout << "," << next;
        previous = current;
        current = next;
    }
}
