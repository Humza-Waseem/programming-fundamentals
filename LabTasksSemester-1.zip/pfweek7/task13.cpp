#include <iostream>
using namespace std;
main()
{
    int n1, n2, n3;
    int n;
    float p1;
    cout << "enter the total numbers:";
    cin >> n;
    while (n <= 5)
    {
        cin >> n1;
        cin >> n2;
        cin >> n3;

        if (n1 < 200 && n2 < 200 && n3 < 200)
        {
            p1 = 3 / 3 * 100;
            cout << p1;
        }
        if (n1 < 200 && n2 < 200 && n3 > 200)
        {
            p1 = 2 / 3 * 100;
            cout << p1;
        }
        if (n1 > 200 && n2 > 200 && n3 < 200)
        {
            p1 = 1 / 3 * 100;
            cout << p1;
        }
    }
}