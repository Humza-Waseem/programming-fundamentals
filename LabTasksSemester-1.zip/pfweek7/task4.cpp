#include <iostream>
using namespace std;
main()
{
    int a;
    int b;
    int table;
    cout << "enter the number to calculate table";
    cin >> b;
    for (a = 1; a <= 10; a++)
    {
        table = a * b;
        cout << b << " * " << a << " = " << table << endl;
    }
}