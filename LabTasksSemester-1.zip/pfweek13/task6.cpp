#include <iostream>
using namespace std;
main()
{

    int arr[4][3] = {
        {0, 0, 0},
        {0, 1, 2},
        {0, 0, 0},
        {2, 1, 0}};
    int count = 0;
    for (int row = 0; row < 4; row++)
    {
        for (int col = 0; col < 3; col++)
        {
            cout << arr[row][col];
            cout << "\t";
        }
        cout << endl;

        
        {
            count= count++;
        }
    }
}
