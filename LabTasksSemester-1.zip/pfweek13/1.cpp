#include <iostream>
using namespace std;

main()
{
    int matrix[3][3] = {
                        {1, 0, 0},
                        {0, 1, 0},
                        {0, 0, 1}
                       };
    // for (int row = 0; row < 3; row++)
    // {
    //     for (int col = 0; col < 3; col++)
    //     {
    //         cout << matrix[row][col];
    //         cout << "\t";
    //     }
    // }
    if (matrix[0][0] == 1 && matrix[1][1] == 1 && matrix[2][2] == 1)
    {
        cout << "IDENTITY MATIX";
    }
    cout << endl;
}