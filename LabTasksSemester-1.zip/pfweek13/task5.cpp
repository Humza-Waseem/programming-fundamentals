#include <iostream>
using namespace std;
main()
{
    string firing;
    string maze[5][5] =
        {
            {".", ".", ".", "*", "*"},
            {".", "*", ".", ".", "."},
            {".", "*", ".", ".", "."},
            {".", "*", ".", ".", "."},
            {".", ".", "*", "*", "."}
            };
       cout<<"Enter firing :";
       cin>>firing;
          for(int row= 0; row <5 ;row++)
          {
            for(int col = 0; col< 5; col++)
            {
                if()
            }
          }  
}

